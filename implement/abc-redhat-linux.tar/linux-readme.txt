This is compiled under Redhat Linux 7.3

Put the executable files abc and abckeys somewhere in your path.

Put the library files abc.msg and abc.hlp in one of the following
places:

	1. In the directory where you are when you start abc up (not
	usually very useful).

	2. The location where your abc source programs are
	stored, namely $HOME/abc/

	3. /usr/lib/abc/
