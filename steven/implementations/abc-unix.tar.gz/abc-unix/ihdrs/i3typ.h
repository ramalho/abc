/* Copyright (c) Stichting Mathematisch Centrum, Amsterdam, 1986. */

/* Type matching */

typedef value btype;
btype valtype();
btype loctype();
/* Procedure must_agree(); */

