/* Copyright (c) Stichting Mathematisch Centrum, Amsterdam, 1986. */

/* screen */

extern value iname;
extern bool outeractive;
extern bool at_nwl;
extern bool Eof;
extern FILE *ifile;
extern FILE *sv_ifile;
extern char *get_line();
extern char q_answer();
extern char *getfmtbuf();

