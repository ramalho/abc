/* Copyright (c) Stichting Mathematisch Centrum, Amsterdam, 1990. */

Visible Porting long filemodtime();
Visible Porting Procedure freepath();
Visible Porting char *curdir();
