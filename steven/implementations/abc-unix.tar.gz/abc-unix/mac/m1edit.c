/* Copyright (c) Stichting Mathematisch Centrum, Amsterdam, 1990. */

/* edit via another editor */

#include "b.h"
#include "main.h"

Visible Procedure ed_file(fname, line, changed)
     string fname;
     intlet line;
     bool *changed;
{
}
