include "codeg.out" 'CODE';
include "messages.out" 'STR#';
include "bundle.out";
include "about.out";
include "dialogs.out";
include "menus.out";
