#include "macdefs.h"

abort()
{
	Debugger();
	exit(2);
}
