/* Copyright (c) Stichting Mathematisch Centrum, Amsterdam, 1988. */

extern char *bws_arg;
extern char *wsp_arg;
#ifndef NDEBUG
extern bool dflag;
#endif
