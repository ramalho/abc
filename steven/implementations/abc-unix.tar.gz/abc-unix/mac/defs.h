/* Copyright (c) Stichting Mathematisch Centrum, Amsterdam, 1986. */

#define MAXHIST 21 /* One more than the number of UNDO's allowed. */

#define SUGGBUFSIZE 128
#define NSUGGSIZE 64

