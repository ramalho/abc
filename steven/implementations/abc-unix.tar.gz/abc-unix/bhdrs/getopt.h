extern int opterr;	/* no error messages if zero */
extern int optopt;	/* option letter found */
extern int optind;	/* argv index of next argument */
extern char *optarg;	/* start of option argument */

extern int getopt();	/* returns option letter or '?' or EOF */
