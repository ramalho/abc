This is ABC for Windows/DOS.

HOW TO INSTALL

Unpack the ZIP file in (for instance) C:\Program Files\ABC\
You will find abc.html, a users manual, and abc-qr.html, the ABC quick
reference, as well as abc.exe, abckeys.exe, and abc.bat.

HOW TO RUN

To start ABC, double click on abc.bat

When you start ABC, the window will open with the Windows default size
of 25 lines and 80 columns; if you want to have a larger default 
window, make a link to abc.bat by selecting it, right clicking, 
and selecting "Create shortcut". Then right-click on the file and 
select 'properties', click on the 'layout'tab, and select 'window size',
for instance of 50 lines.

To change the colours used, select the 'colours' tab, and select 
the colours for the screen text and screen background.

MORE INFORMATION

Full documentation at http://www.cwi.nl/~steven/abc/
